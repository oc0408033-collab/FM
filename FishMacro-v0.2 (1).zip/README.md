# Fish Macro (Android)

Phone version of the Blox Fruits auto-fisher. Same logic as the PC macro: reads the
screen by colour, no code injected into Roblox.

## Get the APK
1. Make a new GitHub repo, upload everything in this folder (keep the `.github` folder).
2. Go to the **Actions** tab -> **Build APK** -> run it (or it runs on every push).
3. Open the finished run, download **FishMacro-apk**, unzip, install `app-debug.apk`.

## Use it
1. Open Fish Macro. Tap **1** (allow draw over apps) and **2** (turn on accessibility).
   If accessibility is greyed out: App info -> three dots -> *Allow restricted settings*.
2. Fill in your bait count. Leave auto buy / auto sell **off** for the first test.
3. Tap **3**, accept the screen capture prompt, open Roblox, stand at your fishing spot.
4. Tap **START** on the little bar at the top. **STOP** to stop, **X** to quit.

## What it does
cast -> waits for the pink "!" -> taps -> plays the reel minigame -> grabs chests -> closes
the catch popup -> repeats. With auto buy/sell on, it walks to the NPC, finds *Shop / Buy Bait /
Basic Bait / Craft / Sell Fish / Confirm* by reading the text on screen, then walks back.

## If something is off (edit `Config.kt`)
- Taps land on a button instead of empty screen: change `PRESS_X / PRESS_Y`.
- Walking does nothing: change `JOY_X / JOY_Y` to where your thumbstick is.
- Walks too far or too little: change *Walk time* in the app.
- Reel bar loses the fish: that is the hard part on phone (finger taps are slower than a mouse).
  Test fishing alone for 30 minutes before turning on auto buy/sell.

## v0.2: floating hub + server hopper
Tap the round **FM** button over Roblox (drag it anywhere) to open the hub:
- **Macro** button switches Fishing / Server hop. **Sea** button cycles Random / 1 / 2 / 3.
- **START / STOP** runs the chosen macro until you stop it. **HOP NEXT** joins one new server and stops.
- **LOW GFX** opens Roblox's own menu and drags Graphics Quality to the lowest (best effort).
Hop loop: opens a random public server of that sea -> waits for the team screen -> waits 7-9 s -> taps the
team -> only then hops again. If hopping opens the wrong sea, fix the Place IDs in the app.
Fishing: yellow chest is now chased whenever it is on the bar; sell step tries Confirm/Yes/Sell All/Accept.
