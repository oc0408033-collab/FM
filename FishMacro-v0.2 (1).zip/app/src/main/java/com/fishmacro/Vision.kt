package com.fishmacro

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

class Frame(val w: Int, val h: Int, val px: IntArray, val t: Long)

/** One reading of the reel bar. All x values are in captured-frame pixels. */
class Bar(val zl: Float, val zr: Float, val fish: Float?, val chest: Float?)

class BarState {
    var y0 = 0
    var y1 = 0
    var zoneW = 0f
}

/**
 * Colour rules ported from the PC macro (WINDOWS/docs/MECHANICS.md).
 * Nothing here depends on fixed pixel positions, only on colours and shapes.
 */
object Vision {

    fun isZone(r: Int, g: Int, b: Int) = g > b + 10 && g > r + 10 && g > 62 && abs(b - r) <= 16
    fun isFish(r: Int, g: Int, b: Int) = b > 110 && b > r + 60 && g > r + 30
    fun isChest(r: Int, g: Int, b: Int) = r > 140 && g > 90 && b < 130 && r > b + 60 && g > b + 20
    private fun isNeutral(r: Int, g: Int, b: Int) = abs(r - g) <= 14 && abs(g - b) <= 14 && g in 70..190
    private fun isDark(r: Int, g: Int, b: Int): Boolean {
        val mx = max(r, max(g, b)); val mn = min(r, min(g, b))
        return mx <= 80 && mx - mn <= 28
    }

    // ---------- bite marker: pink ring with "!" above the head ----------

    private fun isPink(r: Int, g: Int, b: Int): Boolean {
        val mx = max(r, max(g, b)); val mn = min(r, min(g, b))
        if (mx < 110) return false
        val d = mx - mn
        if (d <= 0) return false
        if (d * 255 / mx < 45) return false
        var h = if (mx == r) 60f * ((g - b).toFloat() / d)
        else if (mx == g) 60f * ((b - r).toFloat() / d + 2f)
        else 60f * ((r - g).toFloat() / d + 4f)
        if (h < 0f) h += 360f
        val cv = h / 2f   // OpenCV hue scale 0..179
        return cv >= 158f && cv <= 179.9f
    }

    private fun dilate(m: BooleanArray, w: Int, h: Int): BooleanArray {
        val o = BooleanArray(w * h)
        for (y in 0 until h) for (x in 0 until w) {
            if (!m[y * w + x]) continue
            for (dy in -1..1) {
                val yy = y + dy
                if (yy < 0 || yy >= h) continue
                for (dx in -1..1) {
                    val xx = x + dx
                    if (xx < 0 || xx >= w) continue
                    o[yy * w + xx] = true
                }
            }
        }
        return o
    }

    fun findBite(f: Frame): Boolean {
        val x0 = (0.28f * f.w).toInt(); val x1 = (0.72f * f.w).toInt()
        val y0 = (0.08f * f.h).toInt(); val y1 = (0.62f * f.h).toInt()
        val w = x1 - x0; val h = y1 - y0
        if (w <= 0 || h <= 0) return false
        var m = BooleanArray(w * h)
        var n = 0
        for (y in 0 until h) {
            val base = (y + y0) * f.w + x0
            for (x in 0 until w) {
                val p = f.px[base + x]
                if (isPink((p shr 16) and 255, (p shr 8) and 255, p and 255)) { m[y * w + x] = true; n++ }
            }
        }
        if (n < 15) return false
        m = dilate(dilate(m, w, h), w, h)
        val seen = BooleanArray(w * h)
        val stack = IntArray(w * h)
        for (i in 0 until w * h) {
            if (!m[i] || seen[i]) continue
            var sp = 0
            stack[sp++] = i; seen[i] = true
            var minX = w; var maxX = 0; var minY = h; var maxY = 0; var area = 0
            while (sp > 0) {
                val c = stack[--sp]
                val cx = c % w; val cy = c / w
                area++
                if (cx < minX) minX = cx
                if (cx > maxX) maxX = cx
                if (cy < minY) minY = cy
                if (cy > maxY) maxY = cy
                if (cx > 0 && m[c - 1] && !seen[c - 1]) { seen[c - 1] = true; stack[sp++] = c - 1 }
                if (cx < w - 1 && m[c + 1] && !seen[c + 1]) { seen[c + 1] = true; stack[sp++] = c + 1 }
                if (cy > 0 && m[c - w] && !seen[c - w]) { seen[c - w] = true; stack[sp++] = c - w }
                if (cy < h - 1 && m[c + w] && !seen[c + w]) { seen[c + w] = true; stack[sp++] = c + w }
            }
            val bw = maxX - minX + 1; val bh = maxY - minY + 1
            val big = max(bw, bh)
            val aspect = bw.toFloat() / bh
            val fill = area.toFloat() / (bw * bh)
            if (big >= 0.055f * w && big <= 0.35f * w && aspect >= 0.40f && aspect <= 2.30f && fill >= 0.15f) return true
        }
        return false
    }

    // ---------- reel bar ----------

    private fun firstLast(cnt: IntArray, x0: Int, x1: Int, thr: Int): IntArray? {
        var a = -1; var b = -1
        for (x in x0 until x1) if (cnt[x] >= thr) { if (a < 0) a = x; b = x }
        return if (a < 0) null else intArrayOf(a, b)
    }

    private fun largestRun(cnt: IntArray, x0: Int, x1: Int, thr: Int, gap: Int): IntArray? {
        var bs = -1; var be = -1; var cs = -1; var ce = -1
        for (x in x0 until x1) {
            if (cnt[x] >= thr) {
                if (cs < 0) { cs = x; ce = x }
                else if (x - ce <= gap + 1) ce = x
                else {
                    if (bs < 0 || ce - cs > be - bs) { bs = cs; be = ce }
                    cs = x; ce = x
                }
            }
        }
        if (cs >= 0 && (bs < 0 || ce - cs > be - bs)) { bs = cs; be = ce }
        return if (bs < 0) null else intArrayOf(bs, be)
    }

    /** Looks for the reel bar: a green block sitting on a dark strip. Fills st when found. */
    fun findBar(f: Frame, st: BarState): Boolean {
        val x0 = (0.08f * f.w).toInt(); val x1 = (0.92f * f.w).toInt()
        val y0 = (0.35f * f.h).toInt(); val y1 = (0.97f * f.h).toInt()
        val thr = (0.04f * f.w).toInt()
        val rowCnt = IntArray(f.h + 1)
        for (y in y0 until y1) {
            var c = 0
            val base = y * f.w
            for (x in x0 until x1) {
                val p = f.px[base + x]
                if (isZone((p shr 16) and 255, (p shr 8) and 255, p and 255)) c++
            }
            rowCnt[y] = c
        }
        var bestS = -1; var bestL = 0; var s = -1
        for (y in y0..y1) {
            val ok = y < y1 && rowCnt[y] >= thr
            if (ok && s < 0) s = y
            if (!ok && s >= 0) { val len = y - s; if (len > bestL) { bestL = len; bestS = s }; s = -1 }
        }
        if (bestL < 3 || bestL > 0.14f * f.h) return false
        val ys = bestS; val ye = bestS + bestL
        val col = IntArray(f.w)
        for (y in ys until ye) {
            val base = y * f.w
            for (x in x0 until x1) {
                val p = f.px[base + x]
                if (isZone((p shr 16) and 255, (p shr 8) and 255, p and 255)) col[x]++
            }
        }
        val fl = firstLast(col, x0, x1, max(2, bestL / 2)) ?: return false
        val zl = fl[0]; val zr = fl[1]
        val zw = zr - zl + 1
        if (zw < 0.05f * f.w || zw > 0.30f * f.w) return false
        var dark = 0; var tot = 0
        val lx = max(x0, (zl - 0.8f * zw).toInt()); val rx = min(x1, (zr + 0.8f * zw).toInt())
        for (y in ys until ye) {
            val base = y * f.w
            for (x in lx until rx) {
                if (x in zl..zr) continue
                tot++
                val p = f.px[base + x]
                if (isDark((p shr 16) and 255, (p shr 8) and 255, p and 255)) dark++
            }
        }
        if (tot == 0 || dark.toFloat() / tot < 0.25f) return false
        st.y0 = ys; st.y1 = ye; st.zoneW = zw.toFloat()
        return true
    }

    /** Reads zone / fish / chest positions inside the bar that findBar locked onto. null = bar is gone. */
    fun readBar(f: Frame, st: BarState): Bar? {
        val ys = max(0, st.y0 - 2); val ye = min(f.h, st.y1 + 2)
        val bh = ye - ys
        if (bh < 3 || st.zoneW <= 0f) return null
        val x0 = (0.04f * f.w).toInt(); val x1 = (0.96f * f.w).toInt()
        val tw = st.zoneW / 0.307f                       // track width = zone width / 30.7 %
        val tx0 = max(x0, (f.w / 2f - tw / 2f).toInt())
        val tx1 = min(x1, (f.w / 2f + tw / 2f).toInt())
        val zc = IntArray(f.w); val nc = IntArray(f.w); val fc = IntArray(f.w); val cc = IntArray(f.w)
        var dark = 0; var tot = 0
        for (y in ys until ye) {
            val base = y * f.w
            for (x in x0 until x1) {
                val p = f.px[base + x]
                val r = (p shr 16) and 255; val g = (p shr 8) and 255; val b = p and 255
                if (isZone(r, g, b)) zc[x]++
                else if (isFish(r, g, b)) fc[x]++
                else if (isChest(r, g, b)) cc[x]++
                else if (isNeutral(r, g, b)) nc[x]++
                if (x >= tx0 && x < tx1) { tot++; if (isDark(r, g, b)) dark++ }
            }
        }
        // the dark track must still be there, otherwise the minigame is over
        if (tot == 0 || dark.toFloat() / tot < 0.25f) return null

        val thr = max(2, bh / 2)
        var run = firstLast(zc, tx0, tx1, thr)
        if (run == null || run[1] - run[0] + 1 < 0.5f * st.zoneW) {
            // the "fish is escaping" alarm turns the zone grey: accept grey too
            val sum = IntArray(f.w) { zc[it] + nc[it] }
            val r2 = firstLast(sum, tx0, tx1, thr)
            if (r2 != null && r2[1] - r2[0] + 1 >= 0.5f * st.zoneW) run = r2
        }
        if (run == null) return null

        var zl = run[0].toFloat(); var zr = run[1].toFloat() + 1f
        val fishW = 0.087f * tw
        var fish: Float? = null
        val fr = largestRun(fc, x0, x1, max(2, bh / 3), 3)
        if (fr != null && (fr[1] - fr[0] + 1) >= 0.4f * fishW) fish = (fr[0] + fr[1] + 1) / 2f
        var chest: Float? = null
        val cr = largestRun(cc, x0, x1, max(2, bh / 3), 3)
        if (cr != null && (cr[1] - cr[0] + 1) >= 0.4f * fishW) chest = (cr[0] + cr[1] + 1) / 2f

        val width = zr - zl
        if (width < st.zoneW * 0.93f) {
            // fish or chest tile is sitting on one end of the zone and hiding it: rebuild the hidden end
            val half = fishW / 2f + 6f
            for (o in listOfNotNull(fish, chest)) {
                if (abs(o - zl) <= half) { zl = zr - st.zoneW; break }
                if (abs(o - zr) <= half) { zr = zl + st.zoneW; break }
            }
        } else if (width <= st.zoneW * 1.1f) {
            st.zoneW = 0.9f * st.zoneW + 0.1f * width
        }
        return Bar(zl, zr, fish, chest)
    }
}
