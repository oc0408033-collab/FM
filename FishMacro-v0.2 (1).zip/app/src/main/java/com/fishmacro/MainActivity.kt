package com.fishmacro

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private val REQ = 42
    private lateinit var cfg: Config
    private lateinit var eBait: EditText
    private lateinit var eBuy: EditText
    private lateinit var eSell: EditText
    private lateinit var eWalk: EditText
    private lateinit var eNpc: EditText
    private lateinit var eBaitName: EditText
    private lateinit var sBuy: Switch
    private lateinit var sSell: Switch
    private lateinit var sBehind: Switch
    private lateinit var sHopFirst: Switch
    private lateinit var eSea: EditText
    private lateinit var eMin: EditText
    private lateinit var eMax: EditText
    private lateinit var eTeam: EditText
    private lateinit var ePl1: EditText
    private lateinit var ePl2: EditText
    private lateinit var ePl3: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        cfg = Config(this)
        val pad = (16 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(pad, pad, pad, pad) }

        fun label(t: String) { root.addView(TextView(this).apply { text = t; textSize = 13f; setPadding(0, pad / 2, 0, 0) }) }
        fun num(v: Int): EditText = EditText(this).apply { inputType = InputType.TYPE_CLASS_NUMBER; setText(v.toString()) }
        fun txt(v: String): EditText = EditText(this).apply { setText(v) }
        fun sw(t: String, v: Boolean): Switch = Switch(this).apply { text = t; isChecked = v }
        fun btn(t: String, f: () -> Unit) { root.addView(Button(this).apply { text = t; setOnClickListener { f() } }) }

        label("Fish Macro hub: fishing + server hopper for Blox Fruits. Do steps 1, 2, 3, then use the floating FM button over Roblox (drag it anywhere, tap to open).")
        btn("1. Allow draw over apps") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        btn("2. Turn on accessibility (Fish Macro)") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }

        label("Bait you have right now")
        eBait = num(cfg.baitLeft); root.addView(eBait)
        sBuy = sw("Auto buy bait when it runs low", cfg.autoBuy); root.addView(sBuy)
        label("Bait to buy each time (10, 20, 30...)")
        eBuy = num(cfg.buyAmount); root.addView(eBuy)
        sSell = sw("Auto sell fish", cfg.autoSell); root.addView(sSell)
        label("Sell every this many catches")
        eSell = num(cfg.sellEvery); root.addView(eSell)
        label("NPC name (text above the NPC)")
        eNpc = txt(cfg.npcName); root.addView(eNpc)
        label("Bait name in the shop")
        eBaitName = txt(cfg.baitName); root.addView(eBaitName)
        sBehind = sw("NPC is behind me when I fish", cfg.npcBehind); root.addView(sBehind)
        label("Walk time to NPC (milliseconds)")
        eWalk = num(cfg.walkMs); root.addView(eWalk)

        label("--- Server hopper ---")
        sHopFirst = sw("Hub starts on Server hop (instead of Fishing)", cfg.macro == 1); root.addView(sHopFirst)
        label("Sea to hop in (0 = random sea, 1, 2 or 3)")
        eSea = num(cfg.sea); root.addView(eSea)
        label("Wait after joining, min seconds")
        eMin = num(cfg.dwellMinMs / 1000); root.addView(eMin)
        label("Wait after joining, max seconds")
        eMax = num(cfg.dwellMaxMs / 1000); root.addView(eMax)
        label("Team button text on the join screen")
        eTeam = txt(cfg.teamName); root.addView(eTeam)
        label("Place IDs: Sea 1 / Sea 2 / Sea 3 (only change if hopping opens the wrong sea)")
        ePl1 = txt(cfg.placeId1); root.addView(ePl1)
        ePl2 = txt(cfg.placeId2); root.addView(ePl2)
        ePl3 = txt(cfg.placeId3); root.addView(ePl3)

        btn("3. START (then switch to Roblox)") {
            save()
            if (!Settings.canDrawOverlays(this)) {
                toast("Do step 1 first")
            } else if (MacroAccessibilityService.instance == null) {
                toast("Do step 2 first")
            } else {
                if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
                val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                startActivityForResult(mpm.createScreenCaptureIntent(), REQ)
            }
        }
        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    private fun save() {
        cfg.baitLeft = eBait.text.toString().toIntOrNull() ?: 0
        cfg.buyAmount = (eBuy.text.toString().toIntOrNull() ?: 20).coerceAtLeast(10)
        cfg.sellEvery = (eSell.text.toString().toIntOrNull() ?: 20).coerceAtLeast(1)
        cfg.walkMs = (eWalk.text.toString().toIntOrNull() ?: 1200).coerceIn(200, 6000)
        cfg.npcName = eNpc.text.toString().ifBlank { "Angler" }
        cfg.baitName = eBaitName.text.toString().ifBlank { "Basic Bait" }
        cfg.autoBuy = sBuy.isChecked
        cfg.autoSell = sSell.isChecked
        cfg.npcBehind = sBehind.isChecked
        cfg.macro = if (sHopFirst.isChecked) 1 else 0
        cfg.sea = (eSea.text.toString().toIntOrNull() ?: 1).coerceIn(0, 3)
        val mn = (eMin.text.toString().toIntOrNull() ?: 7).coerceAtLeast(0)
        val mx = (eMax.text.toString().toIntOrNull() ?: 9).coerceAtLeast(mn)
        cfg.dwellMinMs = mn * 1000
        cfg.dwellMaxMs = mx * 1000
        cfg.teamName = eTeam.text.toString().ifBlank { "Marines" }
        cfg.placeId1 = ePl1.text.toString().ifBlank { "2753915549" }
        cfg.placeId2 = ePl2.text.toString().ifBlank { "4442272183" }
        cfg.placeId3 = ePl3.text.toString().ifBlank { "7449423635" }
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ && resultCode == RESULT_OK && data != null) {
            val i = Intent(this, FishService::class.java).putExtra("code", resultCode).putExtra("data", data)
            startForegroundService(i)
            moveTaskToBack(true)
        }
    }
}
