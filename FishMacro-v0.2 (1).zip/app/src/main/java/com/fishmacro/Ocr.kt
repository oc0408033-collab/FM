package com.fishmacro

import android.graphics.Bitmap
import android.graphics.Rect
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions

/** Reads words off the screen so the macro can find "Shop", "Buy Bait", "Sell Fish", etc. by itself. */
object Ocr {
    private val rec by lazy { TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS) }

    class Hit(val text: String, val box: Rect)

    private fun read(f: Frame): List<Hit> {
        val bmp = Bitmap.createBitmap(f.px, f.w, f.h, Bitmap.Config.ARGB_8888)
        val res = Tasks.await(rec.process(InputImage.fromBitmap(bmp, 0)))
        val out = ArrayList<Hit>()
        for (b in res.textBlocks) for (l in b.lines) {
            l.boundingBox?.let { out.add(Hit(l.text, it)) }
            for (e in l.elements) e.boundingBox?.let { out.add(Hit(e.text, it)) }
        }
        return out
    }

    /** Box (in captured-frame pixels) of the first word that matches, or null. */
    fun find(f: Frame, words: List<String>): Rect? {
        val hits = try { read(f) } catch (e: Exception) { return null }
        for (w in words) {
            val key = w.lowercase()
            val m = hits.filter {
                val t = it.text.trim().lowercase()
                if (key == "+") t == "+" else t.contains(key)
            }.minByOrNull { it.text.length }
            if (m != null) return m.box
        }
        return null
    }

    fun has(f: Frame?, word: String): Boolean = f != null && find(f, listOf(word)) != null
}
