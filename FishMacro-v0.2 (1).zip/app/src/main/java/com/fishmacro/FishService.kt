package com.fishmacro

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/** Watches the screen (screen capture) and shows the little START/STOP bar on top of Roblox. */
class FishService : Service() {

    companion object {
        @Volatile var frame: Frame? = null
        @Volatile var screenW = 1920
        @Volatile var screenH = 1080
        @Volatile var scale = 0.5f
    }

    private var projection: MediaProjection? = null
    private var vd: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var thread: HandlerThread? = null
    private var overlay: LinearLayout? = null
    private var statusView: TextView? = null
    private var engine: Engine? = null
    private var hop: HopEngine? = null
    private var perf: PerfTuner? = null
    private var panel: LinearLayout? = null
    private var startBtn: Button? = null
    private lateinit var cfg: Config
    private var closed = false
    private lateinit var wm: WindowManager
    private val ui = Handler(Looper.getMainLooper())

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent == null || projection != null) return START_NOT_STICKY
        startFg()
        @Suppress("DEPRECATION")
        val data = intent.getParcelableExtra<Intent>("data")
        val code = intent.getIntExtra("code", 0)
        if (data == null) { stopSelf(); return START_NOT_STICKY }
        setup(code, data)
        return START_NOT_STICKY
    }

    private fun startFg() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel("fish", "Fish macro", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "fish")
            .setContentTitle("Fish Macro is running")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        else startForeground(1, n)
    }

    private fun setup(code: Int, data: Intent) {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val mp = mpm.getMediaProjection(code, data)
        projection = mp
        thread = HandlerThread("cap").also { it.start() }
        val h = Handler(thread!!.looper)
        mp.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { ui.post { shutdown() } }
        }, h)

        val bw: Int
        val bh: Int
        if (Build.VERSION.SDK_INT >= 30) {
            val b = wm.maximumWindowMetrics.bounds
            bw = b.width(); bh = b.height()
        } else {
            val dm = DisplayMetrics()
            @Suppress("DEPRECATION") wm.defaultDisplay.getRealMetrics(dm)
            bw = dm.widthPixels; bh = dm.heightPixels
        }
        val sw = max(bw, bh); val sh = min(bw, bh)
        val cw = min(K.CAPTURE_W, sw)
        val sc = cw.toFloat() / sw
        val ch = (sh * sc).toInt()
        screenW = sw; screenH = sh; scale = sc

        val rd = ImageReader.newInstance(cw, ch, PixelFormat.RGBA_8888, 2)
        reader = rd
        vd = mp.createVirtualDisplay(
            "fish", cw, ch, resources.displayMetrics.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, rd.surface, null, h
        )
        rd.setOnImageAvailableListener({ r -> grab(r, cw, ch) }, h)

        cfg = Config(this)
        val say: (String) -> Unit = { s ->
            ui.post {
                statusView?.text = s
                if (s == "stopped" && !anyRunning()) startBtn?.text = "START"
            }
        }
        engine = Engine(cfg, say)
        hop = HopEngine(this, cfg, say)
        perf = PerfTuner(say)
        showHub()
    }

    private fun grab(rd: ImageReader, w: Int, h: Int) {
        val img = try { rd.acquireLatestImage() } catch (e: Exception) { null } ?: return
        try {
            val pl = img.planes[0]
            val buf = pl.buffer
            val rs = pl.rowStride
            val ps = pl.pixelStride
            val out = IntArray(w * h)
            var i = 0
            for (y in 0 until h) {
                var o = y * rs
                for (x in 0 until w) {
                    out[i++] = (255 shl 24) or
                        ((buf.get(o).toInt() and 255) shl 16) or
                        ((buf.get(o + 1).toInt() and 255) shl 8) or
                        (buf.get(o + 2).toInt() and 255)
                    o += ps
                }
            }
            frame = Frame(w, h, out, SystemClock.uptimeMillis())
        } finally {
            img.close()
        }
    }

    // ---------- floating hub: drag the round FM button anywhere, tap it to open the menu ----------

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun anyRunning() = (engine?.running == true) || (hop?.running == true)

    private fun stopAll() {
        engine?.stop(); hop?.stop(); perf?.stop()
        startBtn?.text = "START"
    }

    private fun mkBtn(t: String, onClick: (Button) -> Unit): Button = Button(this).apply {
        text = t; textSize = 11f; isAllCaps = false
        minHeight = 0; minimumHeight = 0; minWidth = 0; minimumWidth = 0
        setPadding(dp(8), dp(4), dp(8), dp(4))
        setOnClickListener { onClick(this) }
    }

    private fun row(vararg v: View): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        for (x in v) addView(x, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
    }

    private val macroNames = arrayOf("Macro: Fishing", "Macro: Server hop")
    private val seaNames = arrayOf("Sea: Random", "Sea: 1", "Sea: 2", "Sea: 3")

    private fun showHub() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }

        val bubble = TextView(this).apply {
            text = "FM"; setTextColor(Color.WHITE); textSize = 14f; gravity = Gravity.CENTER
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(0xE61E88E5.toInt()) }
            layoutParams = LinearLayout.LayoutParams(dp(46), dp(46))
        }

        val st = TextView(this).apply { setTextColor(Color.WHITE); textSize = 11f; text = "ready"; setPadding(0, 0, 0, dp(4)) }
        statusView = st

        val macroBtn = mkBtn(macroNames[cfg.macro.coerceIn(0, 1)]) { b ->
            cfg.macro = if (cfg.macro == 1) 0 else 1
            b.text = macroNames[cfg.macro]
        }
        val seaBtn = mkBtn(seaNames[cfg.sea.coerceIn(0, 3)]) { b ->
            cfg.sea = (cfg.sea + 1) % 4
            b.text = seaNames[cfg.sea]
        }
        val start = mkBtn("START") { b ->
            if (anyRunning()) { stopAll() } else {
                panel?.visibility = View.GONE
                if (cfg.macro == 1) hop?.start(false) else engine?.start()
                b.text = "STOP"
            }
        }
        startBtn = start
        val hopNext = mkBtn("HOP NEXT") {
            if (!anyRunning()) { panel?.visibility = View.GONE; hop?.start(true) }
        }
        val gfx = mkBtn("LOW GFX") {
            if (anyRunning()) stopAll()
            panel?.visibility = View.GONE
            perf?.start()
        }
        val quit = mkBtn("QUIT") { shutdown() }

        val pn = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xDD111111.toInt())
            setPadding(dp(8), dp(6), dp(8), dp(6))
            visibility = View.GONE
            addView(st)
            addView(row(macroBtn, seaBtn))
            addView(row(start, hopNext))
            addView(row(gfx, quit))
        }
        panel = pn
        root.addView(bubble); root.addView(pn)

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = dp(12); y = dp(60) }

        var downX = 0f; var downY = 0f; var startX = 0; var startY = 0; var moved = false
        bubble.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX; downY = e.rawY; startX = lp.x; startY = lp.y; moved = false; true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - downX; val dy = e.rawY - downY
                    if (abs(dx) > 10 || abs(dy) > 10) moved = true
                    if (moved) {
                        lp.x = startX + dx.toInt(); lp.y = startY + dy.toInt()
                        try { wm.updateViewLayout(root, lp) } catch (ex: Exception) {}
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) pn.visibility = if (pn.visibility == View.VISIBLE) View.GONE else View.VISIBLE
                    true
                }
                else -> false
            }
        }
        wm.addView(root, lp)
        overlay = root
    }

    private fun shutdown() {
        if (closed) return
        closed = true
        engine?.stop(); hop?.stop(); perf?.stop()
        try { overlay?.let { wm.removeView(it) } } catch (e: Exception) {}
        try { vd?.release() } catch (e: Exception) {}
        try { reader?.close() } catch (e: Exception) {}
        try { projection?.stop() } catch (e: Exception) {}
        thread?.quitSafely()
        frame = null
        stopSelf()
    }

    override fun onDestroy() { shutdown(); super.onDestroy() }
}
