package com.fishmacro

/**
 * Best-effort "low graphics" helper. Uses Roblox's own menu (the same buttons you would tap):
 * Roblox menu -> Settings -> graphics Manual -> drag Graphics Quality to the lowest.
 * It reads the screen to find the buttons, so it may need a retry if the menu looks different.
 */
class PerfTuner(private val say: (String) -> Unit) {

    @Volatile var running = false

    private fun alive() = running

    fun start() {
        if (running) return
        running = true
        Thread {
            try { go() } catch (e: Exception) { say("gfx error: ${e.message}") }
            finally { running = false; say("gfx finished") }
        }.also { it.isDaemon = true; it.start() }
    }

    fun stop() { running = false }

    private fun go() {
        val a = MacroAccessibilityService.instance ?: run { say("turn on accessibility first"); return }
        val sw = Screen.sw(); val sh = Screen.sh()

        say("gfx: opening menu")
        a.tap(0.035f * sw, 0.07f * sh)                      // Roblox icon, top-left
        Screen.sleep(1300, ::alive)
        if (!Screen.tapText(listOf("Settings"), 4000, ::alive)) { say("gfx: menu not found"); return }
        Screen.sleep(900, ::alive)

        say("gfx: manual mode")
        Screen.tapText(listOf("Manual"), 2500, ::alive)
        Screen.sleep(600, ::alive)

        say("gfx: lowest quality")
        val f = FishService.frame
        val r = if (f != null) Ocr.find(f, listOf("Graphics Quality", "Quality")) else null
        if (r != null) {
            val y = r.centerY() / FishService.scale
            a.swipe(0.92f * sw, y, 0.20f * sw, y, 600)       // drag the slider all the way left
            Screen.sleep(900, ::alive)
            a.tap(0.40f * sw, y, 50)                          // and tap the left end of the track
        } else {
            say("gfx: quality slider not found")
        }
        Screen.sleep(700, ::alive)

        if (!Screen.tapText(listOf("Resume", "Close"), 2000, ::alive)) {
            a.performGlobalAction(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_BACK)
        }
    }
}
