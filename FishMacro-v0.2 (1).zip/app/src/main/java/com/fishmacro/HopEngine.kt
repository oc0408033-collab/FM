package com.fishmacro

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.SystemClock
import kotlin.random.Random

/**
 * Server hopper. Opens a random public server of the chosen sea through Roblox's own
 * "join this game" link, waits for the team screen, waits 7-9 s, taps the team, repeats.
 * It never hops again until the team screen is gone. Nothing is injected into Roblox.
 */
class HopEngine(private val ctx: Context, private val cfg: Config, private val say: (String) -> Unit) {

    @Volatile var running = false
    @Volatile var hops = 0
    private var th: Thread? = null

    private fun alive() = running
    private fun now() = SystemClock.uptimeMillis()
    private fun sleep(ms: Long) = Screen.sleep(ms, ::alive)

    /** single = true -> join one new server and stop (the HOP NEXT button). */
    fun start(single: Boolean) {
        if (running) return
        running = true
        th = Thread {
            try {
                if (MacroAccessibilityService.instance == null) { say("turn on accessibility first"); return@Thread }
                while (running) {
                    val ok = hopOnce()
                    if (single) break
                    if (!ok) sleep(2000)
                }
            } catch (e: Exception) {
                say("error: ${e.message}")
            } finally {
                running = false
                say("stopped")
            }
        }.also { it.isDaemon = true; it.start() }
    }

    fun stop() { running = false }

    private fun launch(sea: Int): Boolean {
        val id = when (sea) { 1 -> cfg.placeId1; 2 -> cfg.placeId2; else -> cfg.placeId3 }.trim()
        val i = Intent(Intent.ACTION_VIEW, Uri.parse("roblox://experiences/start?placeId=$id"))
            .setPackage("com.roblox.client")
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        return try { ctx.startActivity(i); true } catch (e: Exception) { false }
    }

    private fun teamVisible(): Boolean {
        val f = FishService.frame ?: return false
        return Ocr.find(f, listOf(cfg.teamName)) != null
    }

    private fun hopOnce(): Boolean {
        val sea = if (cfg.sea in 1..3) cfg.sea else Random.nextInt(1, 4)
        say("hop ${hops + 1}: joining sea $sea")
        if (!launch(sea)) {
            say("can't open Roblox - is it installed?")
            running = false
            return false
        }

        // 1) wait until the team screen shows up (= we are in a new server)
        val end = now() + 70000
        var seen = false
        while (running && now() < end) {
            if (teamVisible()) { seen = true; break }
            sleep(700)
        }
        if (!running) return false
        if (!seen) { say("team screen never showed, trying another server"); return false }

        // 2) pick the team as fast as possible; do not go on until the team screen is gone
        var picked = false
        for (t in 1..10) {
            if (!running) return false
            val f = FishService.frame
            val r = if (f != null) Ocr.find(f, listOf(cfg.teamName)) else null
            if (r == null) { picked = true; break }
            Screen.tapBox(r)
            sleep(500)
        }
        if (!picked) { say("couldn't pick the team, hopping again"); return false }

        // 3) now the 7-9 s timer starts, then we hop
        val lo = cfg.dwellMinMs.coerceAtLeast(0)
        val hi = cfg.dwellMaxMs.coerceAtLeast(lo + 1)
        val wait = Random.nextInt(lo, hi + 1).toLong()
        say("team picked, waiting ${wait / 1000}s")
        sleep(wait)
        if (!running) return false

        hops++
        say("hop $hops done")
        if (cfg.extraStayMs > 0) sleep(cfg.extraStayMs.toLong())
        return true
    }
}
