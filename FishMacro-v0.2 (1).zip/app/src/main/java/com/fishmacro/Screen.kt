package com.fishmacro

import android.graphics.Rect
import android.os.SystemClock

/** Shared "read the screen, find a word, tap it" helpers for the hop and graphics macros. */
object Screen {
    fun sw() = FishService.screenW.toFloat()
    fun sh() = FishService.screenH.toFloat()

    fun sleep(ms: Long, alive: () -> Boolean) {
        var left = ms
        while (alive() && left > 0) {
            val s = minOf(left, 50L)
            Thread.sleep(s)
            left -= s
        }
    }

    fun tapBox(r: Rect) {
        MacroAccessibilityService.instance?.tap(r.centerX() / FishService.scale, r.centerY() / FishService.scale, 60)
    }

    /** Finds the first of [words] on screen and taps it. Gives up after [timeoutMs]. */
    fun tapText(words: List<String>, timeoutMs: Long, alive: () -> Boolean): Boolean {
        val end = SystemClock.uptimeMillis() + timeoutMs
        while (alive() && SystemClock.uptimeMillis() < end) {
            val f = FishService.frame
            if (f != null) {
                val r = Ocr.find(f, words)
                if (r != null) {
                    tapBox(r)
                    sleep(900, alive)
                    return true
                }
            }
            sleep(300, alive)
        }
        return false
    }
}
