package com.fishmacro

import android.graphics.Rect
import android.os.SystemClock
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * The brain. Same cycle as the PC macro:
 * cast -> wait for pink "!" -> tap -> reel minigame (+chests) -> dismiss -> repeat,
 * with a trip to the NPC when bait is low / fish storage is due.
 */
class Engine(private val cfg: Config, private val say: (String) -> Unit) {

    @Volatile var running = false
    private var th: Thread? = null
    private var lastFrameT = 0L
    private var catches = 0
    private var tripFails = 0

    fun start() {
        if (running) return
        running = true
        th = Thread {
            try { loop() } catch (e: Exception) { say("error: ${e.message}") }
            finally { running = false; acc()?.holdEnd(); say("stopped") }
        }.also { it.isDaemon = true; it.start() }
    }

    fun stop() { running = false }

    // ---------- small helpers ----------
    private fun acc() = MacroAccessibilityService.instance
    private fun now() = SystemClock.uptimeMillis()
    private fun sw() = FishService.screenW.toFloat()
    private fun sh() = FishService.screenH.toFloat()
    private fun px() = K.PRESS_X * sw()
    private fun py() = K.PRESS_Y * sh()

    private fun sleep(ms: Long) {
        var left = ms
        while (running && left > 0) { val s = min(left, 50L); Thread.sleep(s); left -= s }
    }

    private fun nextFrame(): Frame? {
        val end = now() + 400
        while (running && now() < end) {
            val f = FishService.frame
            if (f != null && f.t != lastFrameT) { lastFrameT = f.t; return f }
            Thread.sleep(2)
        }
        return FishService.frame
    }

    // ---------- main loop ----------
    private fun loop() {
        if (acc() == null) { say("turn on accessibility first"); return }
        while (running) {
            val needBuy = cfg.autoBuy && cfg.baitLeft <= 1
            val needSell = cfg.autoSell && catches >= cfg.sellEvery
            if (needBuy || needSell) { npcTrip(needBuy, needSell); continue }
            if (!cfg.autoBuy && cfg.baitLeft <= 0) { say("out of bait - stopped"); return }

            cast()
            if (!running) break
            if (!waitBite(25000)) { say("no bite, recasting"); continue }
            cfg.baitLeft = max(0, cfg.baitLeft - 1)
            acc()?.tap(px(), py())
            reel()
            if (!running) break
            dismiss()
            catches++
            say("caught $catches | left ${cfg.baitLeft}")
        }
    }

    private fun cast() {
        say("casting")
        val a = acc() ?: return
        a.holdStart(px(), py())
        sleep(1100)
        a.holdEnd()
        sleep(700)
    }

    private fun waitBite(timeoutMs: Long): Boolean {
        say("waiting for bite")
        val end = now() + timeoutMs
        var seen = 0
        while (running && now() < end) {
            val f = nextFrame() ?: continue
            if (Vision.findBite(f)) seen++ else seen = 0
            if (seen >= 2) return true
        }
        return false
    }

    private fun dismiss() {
        sleep(1700)
        acc()?.tap(px(), py())
        sleep(350)
        acc()?.tap(px(), py())
        sleep(900)
    }

    // ---------- reel minigame ----------
    private class Ctl {
        var init = false
        var t = 0L
        var z = 0f
        var vz = 0f
        var vzMeas = 0f
        var f = 0f
        var vf = 0f
        var hasFish = false
        var hold = false
        var lastSwitch = 0L
        val done = ArrayList<Float>()
        var chestX = 0f
        var chestActive = false
        var chestBegin = 0L
        var chestStart = 0L
    }

    private fun reel() {
        val st = BarState()
        var found = false
        val wait = now() + 3500
        while (running && now() < wait) {
            val f = nextFrame() ?: continue
            if (Vision.findBar(f, st)) { found = true; break }
        }
        if (!found) { say("no reel bar seen"); return }
        say("reeling")
        val c = Ctl()
        var lostSince = 0L
        val end = now() + 30000
        while (running && now() < end) {
            val f = nextFrame() ?: continue
            val bar = Vision.readBar(f, st)
            if (bar == null) {
                if (lostSince == 0L) lostSince = now()
                if (now() - lostSince > 400) break
                continue
            }
            lostSince = 0L
            step(c, bar, f.t, st)
        }
        acc()?.holdEnd()
    }

    /** Keep the green zone on the fish. Hold = zone speeds up to the right, release = to the left. */
    private fun step(c: Ctl, b: Bar, t: Long, st: BarState) {
        val a0 = acc() ?: return
        val tw = st.zoneW / 0.307f
        val ax = 1.92f * tw            // zone acceleration, px/s^2
        val vmax = 0.545f * tw
        val zc = (b.zl + b.zr) / 2f
        val dt = (t - c.t) / 1000f
        val bf = b.fish

        if (!c.init) {
            c.init = true; c.z = zc; c.t = t
            if (bf != null) { c.f = bf; c.hasFish = true }
        } else if (dt > 0.004f) {
            val raw = (zc - c.z) / dt
            c.vzMeas = 0.6f * c.vzMeas + 0.4f * raw
            val model = (c.vz + (if (c.hold) ax else -ax) * dt).coerceIn(-vmax, vmax)
            c.vz = 0.5f * model + 0.5f * c.vzMeas
            if (bf != null) {
                if (c.hasFish) {
                    val fr = (bf - c.f) / dt
                    c.vf = (0.88f * c.vf + 0.12f * fr).coerceIn(-0.12f * tw, 0.12f * tw)
                }
                c.f = bf; c.hasFish = true
            }
            c.z = zc; c.t = t
        } else return

        var tx = if (c.hasFish) c.f else zc
        var tv = c.vf

        // chest: while a yellow chest is on the bar chase it, the moment it is gone go back to the fish
        val ch = b.chest
        if (ch != null) { tx = ch; tv = 0f }

        val lat = 0.10f
        val e = (tx + tv * lat) - (zc + c.vz * lat)
        val ev = tv - c.vz
        val s = e + 0.5f * ev * abs(ev) / ax
        var want = c.hold
        if (s > 0.012f * tw) want = true else if (s < -0.012f * tw) want = false
        if (want != c.hold && t - c.lastSwitch >= 40) {
            if (want) a0.holdStart(px(), py()) else a0.holdEnd()
            c.hold = want
            c.lastSwitch = t
        }
        a0.holdKeepAlive()
    }

    // ---------- NPC trip: buy bait / sell fish ----------
    private fun walk(towardNpc: Boolean) {
        val a = acc() ?: return
        val down = (cfg.npcBehind == towardNpc)
        val x = K.JOY_X * sw(); val y = K.JOY_Y * sh(); val d = K.JOY_DRAG * sh()
        a.swipe(x, y, x, if (down) y + d else y - d, cfg.walkMs.toLong())
        sleep(cfg.walkMs + 400L)
    }

    private fun tapText(vararg words: String, timeoutMs: Long = 4000): Boolean {
        val end = now() + timeoutMs
        while (running && now() < end) {
            val f = FishService.frame
            if (f != null) {
                val r: Rect? = Ocr.find(f, words.toList())
                if (r != null) {
                    acc()?.tap(r.centerX() / FishService.scale, r.centerY() / FishService.scale, 60)
                    sleep(900)
                    return true
                }
            }
            sleep(300)
        }
        return false
    }

    private fun openDialogue(): Boolean {
        repeat(3) {
            if (!running) return false
            if (Ocr.has(FishService.frame, "Shop")) return true
            if (!tapText("Interact", "Talk", timeoutMs = 1500)) tapText(cfg.npcName, timeoutMs = 1500)
            sleep(1800)
        }
        return Ocr.has(FishService.frame, "Shop")
    }

    private fun doBuy(): Boolean {
        say("stocking up")
        if (!Ocr.has(FishService.frame, "Buy Bait")) { if (!tapText("Shop")) return false }
        if (!tapText("Buy Bait")) return false
        if (!tapText(cfg.baitName)) return false
        sleep(600)
        repeat(max(0, cfg.buyAmount / 10 - 1)) { tapText("+", timeoutMs = 1500); sleep(250) }
        if (!tapText("Craft", timeoutMs = 3000)) return false
        sleep(1200)
        cfg.baitLeft = cfg.baitLeft + cfg.buyAmount
        tapText("Back", timeoutMs = 2000)
        return true
    }

    private fun doSell(): Boolean {
        say("offloading fish")
        if (!Ocr.has(FishService.frame, "Sell Fish")) { if (!tapText("Shop")) return false }
        if (!tapText("Sell Fish")) return false
        // the wording of the confirm step varies, so try the common ones ("Sell" last, it also matches the Sell Fish button)
        if (!tapText("Confirm", "Yes", "Sell All", "Accept", "Okay", "Sell", timeoutMs = 5000)) return false
        sleep(1200)
        return true
    }

    private fun closeDialogue() {
        repeat(3) {
            if (!running) return
            if (Ocr.has(FishService.frame, "Nevermind")) { tapText("Nevermind", timeoutMs = 1500); sleep(600) } else return
        }
    }

    private fun npcTrip(buy: Boolean, sell: Boolean) {
        say("walking to npc")
        acc()?.holdEnd()
        walk(true)
        var ok = openDialogue()
        if (ok && buy) ok = doBuy()
        if (ok && sell) ok = doSell()
        closeDialogue()
        say("walking back")
        walk(false)
        if (ok) {
            tripFails = 0
            if (sell) catches = 0
        } else {
            tripFails++
            say("npc trip failed ($tripFails)")
            if (tripFails >= 3) {
                cfg.autoBuy = false; cfg.autoSell = false
                say("trip failed 3 times, auto trips turned off")
            }
        }
    }
}
