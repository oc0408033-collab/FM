package com.fishmacro

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.os.SystemClock
import android.view.accessibility.AccessibilityEvent

/** Does the actual finger work: taps, holds (for the reel minigame) and swipes (to walk). */
class MacroAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile var instance: MacroAccessibilityService? = null
        private const val HOLD_MS = 30L
    }

    private var stroke: GestureDescription.StrokeDescription? = null
    private var holdPath: Path? = null
    private var holdAt = 0L
    private var busyUntil = 0L

    override fun onServiceConnected() { instance = this }
    override fun onUnbind(intent: Intent?): Boolean { instance = null; return super.onUnbind(intent) }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    private fun now() = SystemClock.uptimeMillis()

    private fun fire(s: GestureDescription.StrokeDescription, busy: Long) {
        val wait = busyUntil - now()
        if (wait > 0) Thread.sleep(wait)
        dispatchGesture(GestureDescription.Builder().addStroke(s).build(), null, null)
        busyUntil = now() + busy + 12
    }

    fun tap(x: Float, y: Float, ms: Long = 50) {
        val p = Path().apply { moveTo(x, y) }
        fire(GestureDescription.StrokeDescription(p, 0, ms), ms)
    }

    fun swipe(x1: Float, y1: Float, x2: Float, y2: Float, ms: Long) {
        val p = Path().apply { moveTo(x1, y1); lineTo(x2, y2) }
        fire(GestureDescription.StrokeDescription(p, 0, ms), ms)
    }

    /** Finger goes down and STAYS down until holdEnd(). */
    @Synchronized fun holdStart(x: Float, y: Float) {
        if (stroke != null) return
        val p = Path().apply { moveTo(x, y) }
        val s = GestureDescription.StrokeDescription(p, 0, HOLD_MS, true)
        stroke = s; holdPath = p; holdAt = now()
        fire(s, HOLD_MS)
    }

    /** Call often while holding, it re-sends the "still holding" signal every half second. */
    @Synchronized fun holdKeepAlive() {
        val s = stroke ?: return
        if (now() - holdAt < 500) return
        val n = s.continueStroke(holdPath!!, 0, HOLD_MS, true)
        stroke = n; holdAt = now()
        fire(n, HOLD_MS)
    }

    @Synchronized fun holdEnd() {
        val s = stroke ?: return
        val n = s.continueStroke(holdPath!!, 0, 10, false)
        stroke = null
        fire(n, 10)
    }
}
