package com.fishmacro

import android.content.Context

/** Screen positions (as fractions of the screen). Change these if taps land in the wrong place. */
object K {
    const val PRESS_X = 0.60f      // where we hold/tap to cast + reel (empty spot, not on a button)
    const val PRESS_Y = 0.50f
    const val JOY_X = 0.13f        // walk joystick centre (bottom-left)
    const val JOY_Y = 0.87f
    const val JOY_DRAG = 0.10f     // how far to drag the joystick (fraction of screen height)
    const val CAPTURE_W = 960      // screen is shrunk to this width for reading (fast)
}

class Config(ctx: Context) {
    private val p = ctx.applicationContext.getSharedPreferences("fishmacro", Context.MODE_PRIVATE)

    var baitLeft: Int
        get() = p.getInt("baitLeft", 100)
        set(v) { p.edit().putInt("baitLeft", v).apply() }
    var buyAmount: Int
        get() = p.getInt("buyAmount", 20)
        set(v) { p.edit().putInt("buyAmount", v).apply() }
    var sellEvery: Int
        get() = p.getInt("sellEvery", 20)
        set(v) { p.edit().putInt("sellEvery", v).apply() }
    var walkMs: Int
        get() = p.getInt("walkMs", 1200)
        set(v) { p.edit().putInt("walkMs", v).apply() }
    var autoBuy: Boolean
        get() = p.getBoolean("autoBuy", false)
        set(v) { p.edit().putBoolean("autoBuy", v).apply() }
    var autoSell: Boolean
        get() = p.getBoolean("autoSell", false)
        set(v) { p.edit().putBoolean("autoSell", v).apply() }
    var npcBehind: Boolean
        get() = p.getBoolean("npcBehind", true)
        set(v) { p.edit().putBoolean("npcBehind", v).apply() }
    var npcName: String
        get() = p.getString("npcName", "Angler") ?: "Angler"
        set(v) { p.edit().putString("npcName", v).apply() }
    var baitName: String
        get() = p.getString("baitName", "Basic Bait") ?: "Basic Bait"
        set(v) { p.edit().putString("baitName", v).apply() }

    // ---- hub / server hopper ----
    var macro: Int                       // 0 = fishing, 1 = server hop
        get() = p.getInt("macro", 0)
        set(v) { p.edit().putInt("macro", v).apply() }
    var sea: Int                         // 0 = random sea each hop, 1/2/3 = that sea
        get() = p.getInt("sea", 1)
        set(v) { p.edit().putInt("sea", v).apply() }
    var dwellMinMs: Int
        get() = p.getInt("dwellMin", 7000)
        set(v) { p.edit().putInt("dwellMin", v).apply() }
    var dwellMaxMs: Int
        get() = p.getInt("dwellMax", 9000)
        set(v) { p.edit().putInt("dwellMax", v).apply() }
    var extraStayMs: Int                 // how long to stay in a server after the team is picked
        get() = p.getInt("extraStay", 0)
        set(v) { p.edit().putInt("extraStay", v).apply() }
    var teamName: String
        get() = p.getString("teamName", "Marines") ?: "Marines"
        set(v) { p.edit().putString("teamName", v).apply() }
    var placeId1: String
        get() = p.getString("place1", "2753915549") ?: "2753915549"
        set(v) { p.edit().putString("place1", v).apply() }
    var placeId2: String
        get() = p.getString("place2", "4442272183") ?: "4442272183"
        set(v) { p.edit().putString("place2", v).apply() }
    var placeId3: String
        get() = p.getString("place3", "7449423635") ?: "7449423635"
        set(v) { p.edit().putString("place3", v).apply() }
}
